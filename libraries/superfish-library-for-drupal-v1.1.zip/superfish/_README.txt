ABOUT:
------------------------------------------
This is the Superfish library for the Superfish module of the Drupal CMS.
http://drupal.org/project/superfish

CHANGELOG:
------------------------------------------
Version 1.1, 2011-09-04
---------------------
- File path fixed: style/light-blue.css , style/spring.css , style/white.css

Version 1.0, 2011-03-23
---------------------
- Initial release.